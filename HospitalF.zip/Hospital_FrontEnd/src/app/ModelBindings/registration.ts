export class Registration{
    public firstName:String;
    public lastName:String;
    public emailId:String;
    public password:String;
    public confirmPassword:String;
    public typeOfUser:String;
    public gender:String;
    public dataOfBirth:Date;
}