import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute} from '@angular/router';
import { LoginModel } from '../ModelBindings/login';
import { LoginServiceService } from 'src/Services/login-service.service';
import { Registration } from '../ModelBindings/registration';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 
  public loginRegisBtn : String = 'login';
  public values:any;
  public loginModels :LoginModel = new LoginModel(); 
  public registration : Registration = new Registration();
  constructor(private router:Router,private loginServices:LoginServiceService) { }

  ngOnInit() {
  }

 public toggleBtn(page:any){
   this.loginRegisBtn  = page;
 }

 func(){
   console.log(this.values);
 }

 signin(){
   
  const loginObj :Object = new Object();

  loginObj['userName'] = this.loginModels.userName;
  loginObj['password'] = this.loginModels.password;
  loginObj['typeOfUser'] = this.loginModels.typeOfUser;

  console.log(loginObj);
   this.loginServices.logins(loginObj).then(data=>{
     console.log(data['body']);
     if(data['body']['status'] === 'SUCCESS'){
      sessionStorage.setItem('Token',data.headers.get('Token'));
      console.log(data['body']['users']);
      sessionStorage.setItem('user',JSON.stringify(data['body']['users']));
      console.log(data);
      console.log(data.headers.get('Token'));
      this.router.navigateByUrl("/Hospital/Home");
     }
     
   })
  
  
  // console.log("hi");
 }


Registration(){
  if(this.registration.password === this.registration.confirmPassword){
    console.log(this.registration.dataOfBirth);
    const register :Object = new Object();
    register['firstName'] = this.registration.firstName;
    register['lastName'] = this.registration.lastName;
    register['gender'] = this.registration.gender;
    register['passwords'] = this.registration.password;
    register['confirmPassword'] = this.registration.confirmPassword;
    register['dateOfBirth'] = this.registration.dataOfBirth;
    register['emailId'] = this.registration.emailId;
    register['typeOfUser'] = this.registration.typeOfUser;
    console.log(JSON.stringify(register));
    this.loginServices.registration(register).then(data=>{
      console.log(data);
    })
  }
  

}

}
