import { Component, OnInit } from '@angular/core';
import { GetHospitalinfoService } from 'src/Services/get-hospitalinfo.service';
import { HospitalModel } from '../ModelBindings/hospital';
import { DomSanitizer } from '@angular/platform-browser';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  
   public getAllHospital:any;
   public typeOfUser:any;
   public user:any;
   public startTime:Date;
   public endTime:Date;
   public addNewHospital:Boolean = false;
   public getHospital:any;
   public enableAddIcon:Boolean = false;
   public imgUrl:any;
   public updateHospInfo:Boolean = false;
   public createOrUpdate:String='Create New Hospital';
   public hospModel:HospitalModel=new HospitalModel();
   public initdate = new Date();
   public hospId:string;
   public getAppoint:Boolean = false;
   public selectedHospital:any;
  constructor(private hospitalService:GetHospitalinfoService,private sanitizer:DomSanitizer) { }

  ngOnInit() {
    console.log("hi");
    
     this.user = JSON.parse(sessionStorage.getItem('user'));
     console.log(this.user);
     if(this.user['typeOfUser'] === 'Doctor'){
       this.hospitalService.getByUserId(this.user['userId']).then(data=>{
          console.log(data);
          this.getAllHospital = data['body'];
          if(this.getAllHospital['status'] === 'Success'){
            console.log("null");
            this.enableAddIcon = true;
          }else if(this.getAllHospital.length>0){
            console.log(this.getAllHospital);
          //  this.enableAddIcon = false;
          this.enableAddIcon = true;
       
          }
       })
     }else{
      this.hospitalService.getAllHospitalinfo().then(data =>{
        console.log(data);
        this.getAllHospital = data['body'];
      })
     }
  }

public addHospital(){
  console.log("hosp");
  this.addNewHospital = true;
  this.createOrUpdate = 'Create New Hospital';
}

a(updateOrNew:any){
  
  const hospObj:Object = new Object();
  hospObj['hospName'] = this.hospModel.hospitalName;
  hospObj['hospDescription'] = this.hospModel.hospitalDescription;
  hospObj['hospAddress'] = this.hospModel.hospitalAddress;
  hospObj['appointmentStartTime'] = this.dateTimeConvertor(this.hospModel.hospitalAppointmentStartTime,"Time");
  hospObj['appointmentEndTime'] = this.dateTimeConvertor(this.hospModel.hospitalAppointmentEndTime,"Time");
  hospObj['consultingFees'] = this.hospModel.consultingFees;
  hospObj['enableAppointment'] = this.hospModel.enableAppointment;
  hospObj['img'] = "imgpath";
  hospObj['user']=JSON.parse(sessionStorage.getItem('user'));
  console.log(hospObj);
  if(updateOrNew === 'Create New Hospital'){
   this.hospitalService.createNewHospital(hospObj).then(data=>{
    console.log(data);
    if(data['body']['status'] === 'SUCCESS'){
      this.addNewHospital = false;
      this.hospitalService.getByUserId(hospObj['user']['userId']).then(data=>{
        console.log(data);
        this.getAllHospital = data['body'];
        console.log(this.getAllHospital);
      })
    }
  })
  }else if(updateOrNew === 'Update the Hospital'){
      this.hospitalService.updateOldHospital(hospObj,this.hospId).then(data=>{
        console.log(data['body']);
      })
  }
 

}

dateTimeConvertor(value:Date,format:string){
  
  var datePipe = new DatePipe('en-US');
   if(format === 'Date'){
   return datePipe.transform(value,'dd/MM/yy');
   }else if(format ==='Time'){
     return datePipe.transform(value,'hh:mm a');
   }

}

myFile(img:any){

let file = img.target.files[0];  
const formData = new FormData();
formData.append('file',file);
 console.log(formData.get('file')); 

this.hospModel.img = formData;

}

back(){
  this.addNewHospital = false;
  this.updateHospInfo = false;
}


editHospital(index:any){
  this.addNewHospital = true;
  this.updateHospInfo = true;
  this.createOrUpdate = 'Update the Hospital';
  this.hospId = this.getAllHospital[index]['hospId'];
  console.log(index);
  console.log(this.getAllHospital[index]);
  this.hospModel.hospitalName = this.getAllHospital[index]['hospName'];
  this.hospModel.enableAppointment = this.getAllHospital[index]['enableAppointment'];
  this.hospModel.consultingFees = this.getAllHospital[index]['consultingFees'];
  this.hospModel.hospitalAddress = this.getAllHospital[index]['hospAddress'];
  this.hospModel.hospitalDescription = this.getAllHospital[index]['hospDescription'];
  this.hospModel.hospitalAppointmentEndTime = this.getAllHospital[index]['appointmentEndTime'];
  this.hospModel.hospitalAppointmentStartTime = this.getAllHospital[index]['appointmentStartTime'];
}

deleteHospital(index:number){
    const userId = this.getAllHospital[index]['hospId'];
    
    console.log(this.getAllHospital);
    this.hospitalService.deleteOldHospital(userId).then(data=>{
      const responseVal = data['body'];
      console.log(responseVal);
      if(responseVal['status']==='SUCESS'){
        this.getAllHospital.splice(index,1);
      }else{

      }
      
    })
}

getAppointment(index:number){
  this.getAppoint = true;
  this.selectedHospital = this.getAllHospital[index];

}

}

