import { Component, OnInit, Input, Output, EventEmitter, Optional, Inject, ViewChild } from '@angular/core';
import {CalendarModule} from 'primeng/calendar';
import { NG_VALUE_ACCESSOR, NG_VALIDATORS, NG_ASYNC_VALIDATORS, NgModel } from '@angular/forms';
import { ElementBase } from '../accessor/element.base';

@Component({
  selector: 'app-datepicker',
  templateUrl: './datepicker.component.html',
  styleUrls: ['./datepicker.component.css'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: DatepickerComponent, multi: true }
  ]
})
export class DatepickerComponent extends ElementBase<string> implements OnInit {
  @ViewChild(NgModel)
  model: NgModel;


  @Input()
  public Label:String='';
 

 
  @Input()
  public required:Boolean;
 
  @Input()
  public validationMessage:String;
 
  @Input()
  public readOnly:String;
 
  @Input()
  public types:String;
 
  @Input()
  public pageStyling:String;
 
  @Input()
  public placeholder:String;
  
 public className:any; 

 @Output()
 public getValue = new EventEmitter();

 @Output()
 public dateSelectEvent = new EventEmitter();


  constructor( @Optional()
  @Inject(NG_VALIDATORS)
  validators: Array<any>,
  @Optional()
  @Inject(NG_ASYNC_VALIDATORS)
  asyncValidators: Array<any>
) {
  super(validators, asyncValidators);
}

  ngOnInit() {
    if(this.pageStyling === 'Registration'){
      this.className = 'registrationText';  
 }else if(this.pageStyling === 'login'){
   this.className = 'inputStyle';  
 }
  }

  public validateInputs(){
   console.log(this.value);
    if(this.required){
         if(this.value == undefined || this.value == null){
                 this.validationMessage = this.Label+' is required.';       
             }else if(this.value != undefined || this.value !== null){
                  this.validationMessage = '';
                  }
   }else{
    this.validationMessage = '';
  }

}





}
