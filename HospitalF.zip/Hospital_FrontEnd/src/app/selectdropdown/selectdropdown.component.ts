import { Component, OnInit, Input, OnChanges, ViewChild, Optional, Inject } from '@angular/core';
import { MetaserviceService } from 'src/Services/metaservice.service';
import { NG_VALUE_ACCESSOR, NgModel, NG_ASYNC_VALIDATORS, NG_VALIDATORS } from '@angular/forms';
import { TextBoxComponent } from '../text-box/text-box.component';
import { ElementBase } from '../accessor/element.base';

@Component({
  selector: 'app-selectdropdown',
  templateUrl: './selectdropdown.component.html',
  styleUrls: ['./selectdropdown.component.css'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: SelectdropdownComponent, multi: true }
  ]
})
export class SelectdropdownComponent extends ElementBase<string>  implements OnInit,OnChanges {
 
  @ViewChild(NgModel)
  model: NgModel;

  @Input()
  public Label:String='';
 
  // public values:String;

  @Input()
  public required:Boolean;
 
  @Input()
  public validationMessage:String;
 
  @Input()
  public readOnly:String;
 
  @Input()
  public types:String;
 
  @Input()
  public pageStyling:String;
 
  public className:any; 
  
  @Input()
  public labelName:String;

  public DataArray:any;

  constructor(private services:MetaserviceService, @Optional()
  @Inject(NG_VALIDATORS)
  validators: Array<any>,
  @Optional()
  @Inject(NG_ASYNC_VALIDATORS)
  asyncValidators: Array<any>
) {
  super(validators, asyncValidators);
}
  ngOnInit() {

    if(this.pageStyling === 'Registration'){
      this.className = 'SelectText';  
      }else if(this.pageStyling === 'login'){
      this.className = 'inputStyle';  
     }
        
     if(this.labelName != undefined || this.labelName.length>0 || this.labelName != null){
         this.getDataArray(this.labelName);
     }
  }

  ngOnChanges(){
    if(this.labelName != undefined || this.labelName.length>0 || this.labelName != null){
    //  this.getDataArray(this.labelName);
  }
  }

  public getDataArray(name:String){
    this.DataArray = [];
    this.services.getDataArrayByName(name).subscribe(data => {
      this.DataArray = (data);
      console.log(this.DataArray);
    })

  }

  public validateInputs(){
    
    console.log(this.value);
      if(this.required){
           if(this.value == undefined || this.value == null || this.value.length == 0){
                   this.validationMessage = this.Label+' is required.';       
               }else if(this.value != undefined || this.value !== null || this.value.length !== 0){
                    this.validationMessage = '';
                    }
     }else{
      this.validationMessage = '';
    }
  }

  onchanges($event){
   console.log($event);
  }

}
