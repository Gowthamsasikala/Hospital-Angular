import { Component, OnInit, Input, Optional, Inject, ViewChild } from '@angular/core';
import { NG_VALUE_ACCESSOR, NG_VALIDATORS, NG_ASYNC_VALIDATORS, NgModel } from '@angular/forms';
import { ElementBase } from '../accessor/element.base';

@Component({
  selector: 'app-text-box',
  templateUrl: './text-box.component.html',
  styleUrls: ['./text-box.component.css'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: TextBoxComponent, multi: true }
  ]
})
export class TextBoxComponent extends ElementBase<string> implements OnInit {

  @ViewChild(NgModel)
  model: NgModel;

 @Input()
 public Label:String='';


 @Input()
 public minLength:any;

 @Input()
 public maxLength:any;

 @Input()
 public required:Boolean;

 @Input()
 public validationMessage:String;

 @Input()
 public readOnly:String;

 @Input()
 public types:String;

 @Input()
 public pageStyling:String;

 @Input()
 public placeholder:String;
 
public className:any; 

constructor(
  @Optional()
  @Inject(NG_VALIDATORS)
  validators: Array<any>,
  @Optional()
  @Inject(NG_ASYNC_VALIDATORS)
  asyncValidators: Array<any>
) {
  super(validators, asyncValidators);
}

  ngOnInit() {
if(this.pageStyling === 'Registration'){
     this.className = 'registrationText';  
}else if(this.pageStyling === 'login'){
  this.className = 'inputStyle';  
}

  }


  public validateInputs(){
   
      if(this.required){
           if(this.value == undefined || this.value == null || this.value.length == 0){
                   this.validationMessage = this.Label+' is required.';       
               }else if(this.value != undefined || this.value !== null || this.value.length !== 0){
                    this.validationMessage = '';
                    }
     }else{
      this.validationMessage = '';
    }

  }

}
