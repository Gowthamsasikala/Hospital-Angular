import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {CalendarModule} from 'primeng/calendar';

@Component({
  selector: 'app-datepicker',
  templateUrl: './datepicker.component.html',
  styleUrls: ['./datepicker.component.css']
})
export class DatepickerComponent implements OnInit {
  @Input()
  public Label:String='';
 
  public values:any;
 
  @Input()
  public required:Boolean;
 
  @Input()
  public validationMessage:String;
 
  @Input()
  public readOnly:String;
 
  @Input()
  public types:String;
 
  @Input()
  public pageStyling:String;
 
  @Input()
  public placeholder:String;
  
 public className:any; 

 @Output()
 public getValue = new EventEmitter();


  constructor() { }

  ngOnInit() {
    if(this.pageStyling === 'Registration'){
      this.className = 'registrationText';  
 }else if(this.pageStyling === 'login'){
   this.className = 'inputStyle';  
 }
  }

  public validateInputs(){
   console.log(this.values);
    if(this.required){
         if(this.values == undefined || this.values == null){
                 this.validationMessage = this.Label+' is required.';       
             }else if(this.values != undefined || this.values !== null){
                  this.validationMessage = '';
                  //this.getValue.emit(this.values);
                  }
   }else{
    this.validationMessage = '';
  }

}



}
