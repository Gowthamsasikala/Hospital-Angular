export class HospitalModel {
    public hospitalName:String;
    public hospitalDescription:String;
    public hospitalAddress:String;
    public hospitalAppointmentStartTime:Date;
    public hospitalAppointmentEndTime:Date;
    public consultingFees:String;
    public enableAppointment:String;
    public imgUrl:String;
}