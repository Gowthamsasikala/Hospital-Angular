import { Component, OnInit } from '@angular/core';
import { GetHospitalinfoService } from 'src/Services/get-hospitalinfo.service';
import { HospitalModel } from '../ModelBindings/hospital';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  
   public getAllHospital:any;
   public typeOfUser:any;
   public user:any;
   public startTime:Date;
   public endTime:Date;
   public addNewHospital:Boolean = false;
   public hospModel:HospitalModel=new HospitalModel();
  constructor(private hospitalService:GetHospitalinfoService) { }

  ngOnInit() {
    console.log("hi");
    
     this.user = JSON.parse(sessionStorage.getItem('user'));
     console.log(this.user);
     if(this.user['typeOfUser'] === 'Doctor'){
       this.hospitalService.getByUserId(this.user['userId']).then(data=>{
         
       })
     }else{
      this.hospitalService.getAllHospitalinfo().then(data =>{
        console.log(data);
        this.getAllHospital = data['body'];
      })
     }
  }

public addHospital(){
  console.log("hosp");
  this.addNewHospital = true;
}
time(val){
console.log(val);
}
a(){
  console.log(this.startTime);
  console.log(this.endTime);
  const hospObj:Object = new Object();
  hospObj['hospName'] = this.hospModel.hospitalName;
  hospObj['hospDescription'] = this.hospModel.hospitalDescription;
  hospObj['hospAddress'] = this.hospModel.hospitalAddress;
  hospObj['appointmentStartTime'] = this.hospModel.hospitalAppointmentStartTime;
  hospObj['appointmentEndTime'] = this.hospModel.hospitalAppointmentEndTime;
  hospObj['consultingFees'] = this.hospModel.consultingFees;
  hospObj['enableAppointment'] = this.hospModel.enableAppointment;
  hospObj['imgUrl'] = this.hospModel.imgUrl;
  hospObj['user']=JSON.parse(sessionStorage.getItem('user'));
  console.log(hospObj);

  this.hospitalService.createNewHospital(hospObj).then(data=>{
    console.log(data);
    if(data['body']['status'] === 'SUCCESS'){
      this.addNewHospital = false;
      this.hospitalService.getByUserId(hospObj['user']['userId']).then(data=>{
        console.log(data);
      })
    }
  })

}

myFile(img:any){
  let file = img.target.files[0];
  //console.log(this.convertToBase64(file)); 
  this.convertToBase64(file);
  this.hospModel.imgUrl = sessionStorage.getItem('base64');
  console.log(this.hospModel.imgUrl);
}

public convertToBase64(file:File){
 
  let reader = new FileReader();
  reader.readAsDataURL(file);
  reader.onloadend = function () {
   // console.log(reader.result.toString());
   
    sessionStorage.setItem('base64',reader.result.toString()) ;
       
  };
  reader.onerror = function (error) {
    console.log('Error: ', error);
   
  };

  
  
}

aa(aa:any){

}

}
