import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class GetHospitalinfoService {

  constructor(private http : HttpClient) { }

  getAllHospitalinfo(){
    return this.http.get("http://localhost:8080/hospital/getAllHosp/",{observe: 'response'}).toPromise();
  }
  
  createNewHospital(hospObj:Object){
   return this.http.post("http://localhost:8080/hospital/info/",hospObj,{observe: 'response'}).toPromise();
  }
 
  getByUserId(docId:String){
 return this.http.get("http://localhost:8080/hospital/getByUserId/"+docId+"/",{observe:'response'}).toPromise();
  }


}
