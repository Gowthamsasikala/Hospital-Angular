import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class GetHospitalinfoService {

  constructor(private http : HttpClient) { }

  getAllHospitalinfo(){
    return this.http.get("http://localhost:8080/hospital/getAllHosp/",{observe: 'response'}).toPromise();
  }

}
