import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaderResponse, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {
public values:any;
  constructor(private http:HttpClient) { }

  public logins(loginObj:Object){
   return  this.http.post("http://localhost:8080/user/login/",loginObj,{observe: 'response'}).toPromise();

                  }

}
