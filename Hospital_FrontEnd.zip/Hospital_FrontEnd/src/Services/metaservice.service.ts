import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class MetaserviceService {

  constructor(private http:HttpClient) { }

   getDataArrayByName(fieldName:any){
       return this.http.get('../../assets/metaData/'+fieldName+'.json');
   }

   getGender(fieldName:any){
    return this.http.get('../../assets/metaData/'+fieldName+'.json');
   }


}
