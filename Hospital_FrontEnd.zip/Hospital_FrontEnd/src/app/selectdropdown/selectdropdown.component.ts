import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { MetaserviceService } from 'src/Services/metaservice.service';

@Component({
  selector: 'app-selectdropdown',
  templateUrl: './selectdropdown.component.html',
  styleUrls: ['./selectdropdown.component.css']
})
export class SelectdropdownComponent implements OnInit,OnChanges {
 
  @Input()
  public Label:String='';
 
  public values:String;

  @Input()
  public required:Boolean;
 
  @Input()
  public validationMessage:String;
 
  @Input()
  public readOnly:String;
 
  @Input()
  public types:String;
 
  @Input()
  public pageStyling:String;
 
  public className:any; 
  
  @Input()
  public labelName:String;

  public DataArray:any;

  constructor(private services:MetaserviceService) { }

  ngOnInit() {

    if(this.pageStyling === 'Registration'){
      this.className = 'SelectText';  
      }else if(this.pageStyling === 'login'){
      this.className = 'inputStyle';  
     }
        
     if(this.labelName != undefined || this.labelName.length>0 || this.labelName != null){
         this.getDataArray(this.labelName);
     }
  }

  ngOnChanges(){
    if(this.labelName != undefined || this.labelName.length>0 || this.labelName != null){
    //  this.getDataArray(this.labelName);
  }
  }

  public getDataArray(name:String){
    this.DataArray = [];
    this.services.getDataArrayByName(name).subscribe(data => {
      this.DataArray = (data);
      console.log(this.DataArray);
    })

  }

  public validateInputs(){
    
    console.log(this.values);
      if(this.required){
           if(this.values == undefined || this.values == null || this.values.length == 0){
                   this.validationMessage = this.Label+' is required.';       
               }else if(this.values != undefined || this.values !== null || this.values.length !== 0){
                    this.validationMessage = '';
                    }
     }else{
      this.validationMessage = '';
    }
  }

  onchanges($event){
   console.log($event);
  }

}
