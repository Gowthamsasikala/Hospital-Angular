import { Component, OnInit } from '@angular/core';
import { GetHospitalinfoService } from 'src/Services/get-hospitalinfo.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  
   public getAllHospital:any;
  constructor(private hospitalService:GetHospitalinfoService) { }

  ngOnInit() {
    console.log("hi");
    this.hospitalService.getAllHospitalinfo().then(data =>{
      console.log(data);
      this.getAllHospital = data['body'];
    })
  }

}
