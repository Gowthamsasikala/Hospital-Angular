import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { HomeComponent } from './home/home.component';
import { TextBoxComponent } from './text-box/text-box.component';
import { SelectdropdownComponent } from './selectdropdown/selectdropdown.component';
import { HttpClientModule } from '@angular/common/http';
import { NavigationComponent } from './navigation/navigation.component';
import { routing } from './routing/routes';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { TokenInterceptor } from './Auth/token.interceptor';
import { HospitalComponent } from './hospital/hospital.component'

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
   
    RegistrationComponent,
    HomeComponent,
    TextBoxComponent,
    SelectdropdownComponent,
    NavigationComponent,
    HospitalComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    routing
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: TokenInterceptor,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
