export class LoginModel {
    public userName:String;
    public password:String;
    public typeOfUser:any;
}