import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 
  public loginRegisBtn : String = 'login';
   public values:any;
  constructor(private router:Router) { }

  ngOnInit() {
  }

 public toggleBtn(page:any){
   this.loginRegisBtn  = page;
 }

 func(){
   console.log(this.values);
 }

 signin(){
  this.router.navigateByUrl("/navigate");
  console.log("hi");
 }

}
