import { Routes, RouterModule } from "@angular/router";
import { ModuleWithProviders } from "@angular/compiler/src/core";
import { LoginComponent } from "../login/login.component";
import { Component } from "@angular/core";
import { NavigationComponent } from "../navigation/navigation.component";
import { HospitalComponent } from "../hospital/hospital.component";
import { HomeComponent } from "../home/home.component";

export const routes: Routes = [
    {path:'',component:LoginComponent},

    {path:'Hospital',component:HospitalComponent,children:[
        { path:'Home',component:HomeComponent}
    
    ]}

] 

export const routing :ModuleWithProviders = RouterModule.forRoot(routes);