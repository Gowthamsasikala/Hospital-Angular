import { Routes, RouterModule } from "@angular/router";
import { ModuleWithProviders } from "@angular/compiler/src/core";
import { LoginComponent } from "../login/login.component";
import { Component } from "@angular/core";
import { NavigationComponent } from "../navigation/navigation.component";

export const routes: Routes = [
    {path:'',component:LoginComponent},
    {path:'navigate',component:NavigationComponent}

] 

export const routing :ModuleWithProviders = RouterModule.forRoot(routes);