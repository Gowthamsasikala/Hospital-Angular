import { Component, OnInit } from '@angular/core';
import { NavigationServiceService } from 'src/Services/navigation-service.service';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements OnInit {
  
  public NavigateData:any;
  public enableHamburger:Boolean = false;
  constructor(private service :NavigationServiceService) { }

  ngOnInit() {
    this.service.getNavigationNames().subscribe(data=>{
      console.log(data);
      this.NavigateData = data;
    })
  }

  hamburgerClick(){
    this.enableHamburger = !this.enableHamburger;
    console.log(this.enableHamburger);
  }

}
