import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-text-box',
  templateUrl: './text-box.component.html',
  styleUrls: ['./text-box.component.css']
})
export class TextBoxComponent implements OnInit {

 @Input()
 public Label:String='';

 public values:String;

 @Input()
 public minLength:any;

 @Input()
 public maxLength:any;

 @Input()
 public required:Boolean;

 @Input()
 public validationMessage:String;

 @Input()
 public readOnly:String;

 @Input()
 public types:String;

 @Input()
 public pageStyling:String;

 @Input()
 public placeholder:String;
 
public className:any; 

  constructor() { }

  ngOnInit() {
if(this.pageStyling === 'Registration'){
     this.className = 'registrationText';  
}else if(this.pageStyling === 'login'){
  this.className = 'inputStyle';  
}

  }


  public validateInputs(){
   
      if(this.required){
           if(this.values == undefined || this.values == null || this.values.length == 0){
                   this.validationMessage = this.Label+' is required.';       
               }else if(this.values != undefined || this.values !== null || this.values.length !== 0){
                    this.validationMessage = '';
                    }
     }else{
      this.validationMessage = '';
    }

  }

}
